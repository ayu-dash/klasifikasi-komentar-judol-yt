Submission UAS Machine Learning - Deteksi Komentar Judol

Files included:
1. notebook uas.ipynb: Main source code and analysis.
2. comments_from_scraping_new.csv: The dataset used.
3. src/: Directory containing helper scripts (labeling, scraping, etc.).
4. requirements.txt: Python dependencies.
